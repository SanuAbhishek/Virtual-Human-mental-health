// Global variables
let currentLanguage = 'en';
let moodScore = 50;
let stressScore = 50;
let detectedTopics = [];
let chatHistory = [];

// Gemini API Configuration
const GEMINI_API_KEY = 'AIzaSyDdvJivuOONa6sggsldJPO9hj-4fO8zbR8'; // Replace with your actual API key
const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${AIzaSyDdvJivuOONa6sggsldJPO9hj-4fO8zbR8}`;
import { GoogleGenAI } from '@google/genai';

const client = new GoogleGenAI({});

// 1. First turn
const interaction1 = await client.interactions.create({
    model: 'gemini-2.5-flash',
    input: 'Hi, my name is Phil.'
});
console.log(`Model: ${interaction1.outputs[interaction1.outputs.length - 1].text}`);

// 2. Second turn (passing previous_interaction_id)
const interaction2 = await client.interactions.create({
    model: 'gemini-2.5-flash',
    input: 'What is my name?',
    previous_interaction_id: interaction1.id
});
console.log(`Model: ${interaction2.outputs[interaction2.outputs.length - 1].text}`);

// Mental Health Context for AI
const MENTAL_HEALTH_CONTEXT = `You are LimitsTalk AI, a compassionate mental health assistant designed to help students with stress, depression, and anxiety. 
Guidelines for responses:
1. Be empathetic, non-judgmental, and supportive
2. Use evidence-based therapeutic approaches (CBT, mindfulness, etc.)
3. Never give medical advice or diagnoses
4. Always encourage professional help when needed
5. Provide coping strategies and validation
6. Ask open-ended questions to understand feelings
7. Maintain professional boundaries while being warm
8. Focus on strengths and resilience
9. Suggest practical, actionable steps
10. Recognize and validate emotions

Important safety protocols:
- If user mentions self-harm or suicide, provide crisis resources immediately
- If user needs immediate help, encourage contacting professionals
- Always prioritize safety over conversation flow

Current time and date: ${new Date().toLocaleString()}`;

// Emotion analysis patterns
const EMOTION_KEYWORDS = {
    anxiety: ['anxious', 'worried', 'nervous', 'panic', 'overwhelmed', 'scared', 'fear'],
    depression: ['depressed', 'sad', 'hopeless', 'empty', 'tired', 'worthless', 'guilty'],
    stress: ['stressed', 'pressure', 'burnout', 'exhausted', 'tense', 'frustrated'],
    positive: ['happy', 'good', 'better', 'improving', 'hopeful', 'calm', 'relieved']
};

// Crisis resources by language
const CRISIS_RESOURCES = {
    en: {
        suicide: '988 Suicide & Crisis Lifeline',
        text: 'Text HOME to 741741',
        website: 'https://988lifeline.org'
    },
    es: {
        suicide: 'Línea de Prevención del Suicidio: 988',
        text: 'Texto AYUDA al 741741',
        website: 'https://suicidepreventionlifeline.org/help-yourself/en-espanol/'
    },
    fr: {
        suicide: '3114 - Prévention Suicide',
        text: 'Text SOS to 3114',
        website: 'https://3114.fr'
    }
};

// Chat History Management
let conversationHistory = [
    {
        role: "user",
        parts: [{ text: MENTAL_HEALTH_CONTEXT }]
    },
    {
        role: "model",
        parts: [{ text: "I understand. I am MindCare AI, ready to provide compassionate mental health support. How can I help you today?" }]
    }
];

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    initializeLanguage();
    initializeChatbot();
    updateAnalysisDisplay();
    
    // Set up event listeners
    document.getElementById('languageSelect').addEventListener('change', changeLanguage);
    
    // Initialize questionnaire
    initializeQuestionnaire();
});

// Language Management
function initializeLanguage() {
    const savedLanguage = localStorage.getItem('preferredLanguage') || 'en';
    document.getElementById('languageSelect').value = savedLanguage;
    currentLanguage = savedLanguage;
    updateLanguageContent();
}

function changeLanguage() {
    const newLanguage = document.getElementById('languageSelect').value;
    currentLanguage = newLanguage;
    localStorage.setItem('preferredLanguage', newLanguage);
    updateLanguageContent();
    
    // Notify user
    showNotification(`Language changed to ${getLanguageName(newLanguage)}`, 'success');
}

function getLanguageName(code) {
    const languages = {
        'en': 'English',
        'es': 'Spanish',
        'fr': 'French',
        'hi': 'Hindi',
        'zh': 'Chinese',
        'ar': 'Arabic'
    };
    return languages[code] || 'English';
}

function updateLanguageContent() {
    // This would typically connect to a translation service
    // For demo, we'll just update a few elements
    const elements = document.querySelectorAll('[data-translate]');
    elements.forEach(element => {
        const key = element.getAttribute('data-translate');
        element.textContent = getTranslation(key, currentLanguage);
    });
}

function getTranslation(key, language) {
    // Simple translation dictionary (you would expand this)
    const translations = {
        'welcome': {
            'en': 'Welcome to Limits talk',
            'es': 'Bienvenido a limisTalk',
            'hi': 'LimitsTalk एआई में आपका स्वागत है'
        }
    };
    
    return translations[key]?.[language] || translations[key]?.['en'] || key;
}

// Chatbot Functions
function initializeChatbot() {
    // Load previous chat history
    const savedChat = localStorage.getItem('chatHistory');
    if (savedChat) {
        chatHistory = JSON.parse(savedChat);
        loadChatHistory();
    }
    
    // Load conversation history
    const savedConvo = localStorage.getItem('conversationHistory');
    if (savedConvo) {
        conversationHistory = JSON.parse(savedConvo);
    }
}

function sendMessage() {
    const userInput = document.getElementById('userInput');
    const message = userInput.value.trim();
    
    if (!message) return;
    
    // Add user message to chat
    addMessageToChat(message, 'user');
    userInput.value = '';
    
    // Show typing indicator
    showTypingIndicator();
    
    // Process message with AI
    processWithAI(message);
}

function setQuickResponse(text) {
    document.getElementById('userInput').value = text;
}

function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

function addMessageToChat(message, sender, saveToHistory = true) {
    const chatMessages = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    
    const now = new Date();
    const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    messageDiv.innerHTML = `
        <div class="message-content">${escapeHtml(message)}</div>
        <div class="message-time">${timeString}</div>
    `;
    
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    // Save to history
    if (saveToHistory) {
        chatHistory.push({
            sender,
            message,
            timestamp: now.toISOString()
        });
        
        // Keep only last 50 messages
        if (chatHistory.length > 50) {
            chatHistory = chatHistory.slice(-50);
        }
        
        localStorage.setItem('chatHistory', JSON.stringify(chatHistory));
    }
}

function loadChatHistory() {
    const chatMessages = document.getElementById('chatMessages');
    
    // Clear existing messages except the first AI message
    const existingMessages = chatMessages.querySelectorAll('.message');
    for (let i = 1; i < existingMessages.length; i++) {
        existingMessages[i].remove();
    }
    
    // Add history messages
    chatHistory.forEach(item => {
        if (item.sender !== 'system') {
            addMessageToChat(item.message, item.sender, false);
        }
    });
}

function showTypingIndicator() {
    const chatMessages = document.getElementById('chatMessages');
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message ai-message';
    typingDiv.id = 'typingIndicator';
    
    typingDiv.innerHTML = `
        <div class="message-content">
            <div class="typing-dots">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    `;
    
    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function removeTypingIndicator() {
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

async function processWithAI(userMessage) {
    try {
        // Analyze sentiment and topics
        analyzeMessageContent(userMessage);
        
        // Call Gemini API
        const response = await callGeminiAPI(userMessage);
        
        // Remove typing indicator
        removeTypingIndicator();
        
        // Add AI response to chat
        addMessageToChat(response, 'ai');
        
        // Update analysis
        updateAnalysisFromMessage(userMessage, response);
        
    } catch (error) {
        console.error('AI processing error:', error);
        removeTypingIndicator();
        
        // Fallback response
        const fallbackResponses = [
            "I understand you're sharing something important. Could you tell me more about how this makes you feel?",
            "Thank you for sharing that. Remember, it's okay to not be okay. Would you like to explore some coping strategies together?",
            "I hear you. Let's work through this together. What's one small thing that might help right now?"
        ];
        
        const randomResponse = fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
        addMessageToChat(randomResponse, 'ai');
    }
}

// Function to call Gemini API
async function callGeminiAPI(userMessage) {
    try {
        // Check for crisis keywords
        if (isCrisisSituation(userMessage)) {
            return handleCrisisSituation(userMessage);
        }
        
        // Add user message to history
        conversationHistory.push({
            role: "user",
            parts: [{ text: userMessage }]
        });
        
        // Prepare API request
        const requestBody = {
            contents: conversationHistory,
            generationConfig: {
                temperature: 0.7,
                topK: 40,
                topP: 0.95,
                maxOutputTokens: 1024,
            },
            safetySettings: [
                {
                    category: "HARM_CATEGORY_HARASSMENT",
                    threshold: "BLOCK_MEDIUM_AND_ABOVE"
                },
                {
                    category: "HARM_CATEGORY_HATE_SPEECH",
                    threshold: "BLOCK_MEDIUM_AND_ABOVE"
                },
                {
                    category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                    threshold: "BLOCK_MEDIUM_AND_ABOVE"
                },
                {
                    category: "HARM_CATEGORY_DANGEROUS_CONTENT",
                    threshold: "BLOCK_MEDIUM_AND_ABOVE"
                }
            ]
        };
        
        // Make API call
        const response = await fetch(GEMINI_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestBody)
        });
        
        if (!response.ok) {
            throw new Error(`API Error: ${response.status}`);
        }
        
        const data = await response.json();
        
        // Extract AI response
        let aiResponse = '';
        if (data.candidates && data.candidates[0] && data.candidates[0].content) {
            aiResponse = data.candidates[0].content.parts[0].text;
        } else {
            aiResponse = "I understand you're reaching out. Could you tell me more about what you're experiencing?";
        }
        
        // Add AI response to history
        conversationHistory.push({
            role: "model",
            parts: [{ text: aiResponse }]
        });
        
        // Limit history to last 10 exchanges
        if (conversationHistory.length > 20) {
            conversationHistory = [
                conversationHistory[0], // Keep context
                conversationHistory[1], // Keep initial response
                ...conversationHistory.slice(-18) // Keep recent 9 exchanges
            ];
        }
        
        // Save conversation history
        localStorage.setItem('conversationHistory', JSON.stringify(conversationHistory));
        
        return aiResponse;
        
    } catch (error) {
        console.error('Gemini API Error:', error);
        
        // Fallback responses based on detected emotion
        const emotion = detectEmotion(userMessage);
        return getFallbackResponse(emotion);
    }
}

// Analyze message content for emotions and topics
function analyzeMessageContent(message) {
    const lowerMessage = message.toLowerCase();
    
    // Detect emotions
    detectedTopics = [];
    let moodChange = 0;
    let stressChange = 0;
    
    // Check for anxiety keywords
    if (EMOTION_KEYWORDS.anxiety.some(keyword => lowerMessage.includes(keyword))) {
        detectedTopics.push('anxiety');
        moodChange -= 10;
        stressChange += 15;
    }
    
    // Check for depression keywords
    if (EMOTION_KEYWORDS.depression.some(keyword => lowerMessage.includes(keyword))) {
        detectedTopics.push('depression');
        moodChange -= 15;
        stressChange += 10;
    }
    
    // Check for stress keywords
    if (EMOTION_KEYWORDS.stress.some(keyword => lowerMessage.includes(keyword))) {
        detectedTopics.push('stress');
        moodChange -= 5;
        stressChange += 20;
    }
    
    // Check for positive keywords
    if (EMOTION_KEYWORDS.positive.some(keyword => lowerMessage.includes(keyword))) {
        detectedTopics.push('improvement');
        moodChange += 20;
        stressChange -= 10;
    }
    
    // Update scores
    moodScore = Math.max(0, Math.min(100, moodScore + moodChange));
    stressScore = Math.max(0, Math.min(100, stressScore + stressChange));
    
    // Remove duplicates
    detectedTopics = [...new Set(detectedTopics)];
    
    // Update display
    updateAnalysisDisplay();
}

// Detect emotion from message
function detectEmotion(message) {
    const lowerMessage = message.toLowerCase();
    
    if (EMOTION_KEYWORDS.anxiety.some(k => lowerMessage.includes(k))) return 'anxiety';
    if (EMOTION_KEYWORDS.depression.some(k => lowerMessage.includes(k))) return 'depression';
    if (EMOTION_KEYWORDS.stress.some(k => lowerMessage.includes(k))) return 'stress';
    if (EMOTION_KEYWORDS.positive.some(k => lowerMessage.includes(k))) return 'positive';
    
    return 'neutral';
}

// Get fallback response based on emotion
function getFallbackResponse(emotion) {
    const responses = {
        anxiety: [
            "I hear that you're feeling anxious. That's completely valid. Let's try a simple grounding technique: Name 5 things you can see, 4 things you can touch, 3 things you can hear, 2 things you can smell, and 1 thing you can taste.",
            "Anxiety can feel overwhelming. Remember, these feelings are temporary. Would you like to try a breathing exercise together? Inhale for 4 counts, hold for 4, exhale for 6.",
            "It takes courage to talk about anxiety. What's one small thing that usually helps you feel a bit more grounded?"
        ],
        depression: [
            "I'm really glad you're reaching out. Depression can make everything feel heavy. You're not alone in this. What's one thing, no matter how small, that brought you even a tiny bit of peace recently?",
            "Depression often lies to us about our worth. The fact that you're here, reaching out, shows incredible strength. Would you like to share what's been particularly difficult lately?",
            "Remember that depression is an illness, not a personal failing. Healing takes time. Is there a professional you feel comfortable talking to about these feelings?"
        ],
        stress: [
            "Stress can feel like carrying a heavy load. Let's set it down together for a moment. What's one thing causing you stress that you can temporarily set aside?",
            "When we're stressed, our thoughts can race. Try this: Write down everything on your mind without judgment. Sometimes seeing it on paper makes it feel more manageable.",
            "Stress often comes from feeling out of control. What's one small thing within your control that you can do right now to care for yourself?"
        ],
        positive: [
            "It's wonderful to hear you're feeling better! Celebrating small victories is important. What helped contribute to this improvement?",
            "Progress isn't always linear, so moments of relief are worth noting. How can you build on this positive feeling?",
            "I'm genuinely happy to hear you're doing better. Remember this feeling when things get tough again - it's proof that difficult feelings pass."
        ],
        neutral: [
            "Thank you for sharing. I'm here to listen without judgment. Could you tell me more about what's on your mind?",
            "Sometimes just putting feelings into words can be helpful. What would you like to talk about today?",
            "I'm listening. Take your time - there's no rush. What's been on your mind lately?",
            "hii 1 Calm Down my Dear... You R The Best"
        ]
    };
    
    const emotionResponses = responses[emotion] || responses.neutral;
    return emotionResponses[Math.floor(Math.random() * emotionResponses.length)];
}

// Check for crisis situation
function isCrisisSituation(message) {
    const crisisKeywords = [
        'suicide', 'kill myself', 'end my life', 'want to die',
        'hurting myself', 'self harm', 'can\'t go on', 'no reason to live'
    ];
    
    const lowerMessage = message.toLowerCase();
    return crisisKeywords.some(keyword => lowerMessage.includes(keyword));
}

// Handle crisis situation
function handleCrisisSituation(message) {
    const resources = CRISIS_RESOURCES[currentLanguage] || CRISIS_RESOURCES.en;
    
    return `I hear that you're in significant pain, go to cse 5 th floor and I'm deeply concerned for your safety. 
    
**Immediate Help Resources:**
- **Crisis Lifeline:** ${resources.suicide}
- **Crisis Text Line:** ${resources.text}
- **Website:** ${resources.website}

**Please reach out to one of these resources right now.** They have trained professionals who can provide immediate support.

You don't have to go through this alone. Your life matters, and there are people who want to help you through this difficult time.

Would you like me to help you connect with any of these resources?`;
}

// Update analysis from conversation
function updateAnalysisFromMessage(userMessage, aiResponse) {
    // Analyze AI response for suggestions
    const lowerResponse = aiResponse.toLowerCase();
    
    // Check for coping strategies in response
    const strategies = [];
    if (lowerResponse.includes('breathing') || lowerResponse.includes('breathe')) {
        strategies.push('Breathing Exercise');
    }
    if (lowerResponse.includes('ground') || lowerResponse.includes('5 things')) {
        strategies.push('Grounding Technique');
    }
    if (lowerResponse.includes('write') || lowerResponse.includes('journal')) {
        strategies.push('Journaling');
    }
    if (lowerResponse.includes('professional') || lowerResponse.includes('therapist')) {
        strategies.push('Professional Referral');
    }
    
    // Update topics list
    if (strategies.length > 0) {
        const topicsList = document.getElementById('topicsList');
        strategies.forEach(strategy => {
            if (!topicsList.innerHTML.includes(strategy)) {
                topicsList.innerHTML += `<span class="topic-tag">${strategy}</span>`;
            }
        });
    }
    
    // Update stress level based on conversation
    setTimeout(() => {
        stressScore = Math.max(0, stressScore - 5);
        updateAnalysisDisplay();
    }, 1000);
}

// Update analysis display
function updateAnalysisDisplay() {
    // Update mood level
    let moodText = '';
    if (moodScore > 70) moodText = 'Positive';
    else if (moodScore > 40) moodText = 'Neutral';
    else if (moodScore > 20) moodText = 'Low';
    else moodText = 'Depressed';
    
    document.getElementById('moodLevel').textContent = moodText;
    document.getElementById('moodProgress').style.width = `${moodScore}%`;
    
    // Update stress level
    let stressText = '';
    if (stressScore > 70) stressText = 'High';
    else if (stressScore > 40) stressText = 'Moderate';
    else if (stressScore > 20) stressText = 'Low';
    else stressText = 'Minimal';
    
    document.getElementById('stressLevel').textContent = stressText;
    document.getElementById('stressProgress').style.width = `${stressScore}%`;
    
    // Update topics
    if (detectedTopics.length > 0) {
        document.getElementById('topics').textContent = detectedTopics.join(', ');
        document.getElementById('topicsList').innerHTML = 
            detectedTopics.map(topic => `<span class="topic-tag">${topic}</span>`).join('');
    }
}

// Helper function to escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Scroll to section
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
    }
}

// Questionnaire Functions
function initializeQuestionnaire() {
    // Add event listeners for quick assessment
    const submitBtn = document.querySelector('.submit-btn');
    if (submitBtn) {
        submitBtn.addEventListener('click', calculateQuickAssessment);
    }
}

function calculateQuickAssessment() {
    // Get values from quick assessment
    const q1 = document.querySelector('input[name="q1"]:checked');
    const q2 = document.querySelector('input[name="q2"]:checked');
    
    if (!q1 || !q2) {
        showNotification('Please answer all questions', 'warning');
        return;
    }
    
    const score = parseInt(q1.value) + parseInt(q2.value);
    
    // Get result content div
    const resultDiv = document.getElementById('resultContent');
    const resultCard = document.getElementById('assessmentResult');
    
    let resultHTML = '';
    let recommendation = '';
    
    if (score <= 2) {
        resultHTML = `
            <div class="result-level positive">
                <h5><i class="fas fa-smile"></i> Minimal Distress</h5>
                <p>Your responses suggest minimal symptoms of depression or anxiety.</p>
            </div>
        `;
        recommendation = "Continue practicing self-care and mindfulness.";
        moodScore += 10;
    } else if (score <= 4) {
        resultHTML = `
            <div class="result-level moderate">
                <h5><i class="fas fa-meh"></i> Mild to Moderate Distress</h5>
                <p>You may be experiencing some symptoms that could benefit from support.</p>
            </div>
        `;
        recommendation = "Consider exploring coping strategies and self-help resources.";
        moodScore -= 5;
        stressScore += 10;
    } else {
        resultHTML = `
            <div class="result-level severe">
                <h5><i class="fas fa-frown"></i> Significant Distress</h5>
                <p>Your responses indicate significant symptoms that may benefit from professional support.</p>
            </div>
        `;
        recommendation = "Consider speaking with a mental health professional for personalized support.";
        moodScore -= 15;
        stressScore += 20;
    }
    
    resultHTML += `
        <div class="result-details">
            <p><strong>Score:</strong> ${score}/6</p>
            <p><strong>Recommendation:</strong> ${recommendation}</p>
            <div class="result-actions">
                <button onclick="scrollToSection('chat')" class="action-btn">
                    <i class="fas fa-comment"></i> Talk to AI Assistant
                </button>
                <button onclick="scrollToSection('resources')" class="action-btn">
                    <i class="fas fa-hands-helping"></i> View Resources
                </button>
            </div>
        </div>
    `;
    
    resultDiv.innerHTML = resultHTML;
    resultCard.classList.remove('hidden');
    
    // Update analysis display
    detectedTopics.push('assessment');
    updateAnalysisDisplay();
    
    // Scroll to result
    resultCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Show notification
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existing = document.querySelector('.notification');
    if (existing) existing.remove();
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 
                         type === 'error' ? 'exclamation-circle' : 
                         type === 'warning' ? 'exclamation-triangle' : 
                         'info-circle'}"></i>
        <span>${message}</span>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Show with animation
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Add CSS for notifications and result levels
const additionalStyles = document.createElement('style');
additionalStyles.textContent = `
    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 8px;
        background: white;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 10000;
        transform: translateX(120%);
        transition: transform 0.3s ease;
        max-width: 350px;
    }
    
    .notification.show {
        transform: translateX(0);
    }
    
    .notification.success {
        border-left: 4px solid #51cf66;
    }
    
    .notification.error {
        border-left: 4px solid #ff6b6b;
    }
    
    .notification.warning {
        border-left: 4px solid #ff922b;
    }
    
    .notification.info {
        border-left: 4px solid #4a6fa5;
    }
    
    .notification i {
        font-size: 1.2rem;
    }
    
    .notification.success i {
        color: #51cf66;
    }
    
    .notification.error i {
        color: #ff6b6b;
    }
    
    .notification.warning i {
        color: #ff922b;
    }
    
    .notification.info i {
        color: #4a6fa5;
    }
    
    .typing-dots {
        display: flex;
        gap: 4px;
    }
    
    .typing-dots span {
        width: 8px;
        height: 8px;
        background: rgba(255, 255, 255, 0.7);
        border-radius: 50%;
        animation: typing 1.4s infinite ease-in-out both;
    }
    
    .typing-dots span:nth-child(1) {
        animation-delay: -0.32s;
    }
    
    .typing-dots span:nth-child(2) {
        animation-delay: -0.16s;
    }
    
    @keyframes typing {
        0%, 80%, 100% { transform: scale(0); }
        40% { transform: scale(1.0); }
    }
    
    .result-level {
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1rem;
    }
    
    .result-level.positive {
        background: rgba(81, 207, 102, 0.1);
        border-left: 4px solid #51cf66;
    }
    
    .result-level.moderate {
        background: rgba(255, 146, 43, 0.1);
        border-left: 4px solid #ff922b;
    }
    
    .result-level.severe {
        background: rgba(255, 107, 107, 0.1);
        border-left: 4px solid #ff6b6b;
    }
    
    .result-actions {
        display: flex;
        gap: 1rem;
        margin-top: 1rem;
        flex-wrap: wrap;
    }
    
    .action-btn {
        padding: 0.5rem 1rem;
        background: var(--primary-color);
        color: white;
        border: none;
        border-radius: var(--border-radius);
        cursor: pointer;
        transition: var(--transition);
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .action-btn:hover {
        background: var(--secondary-color);
    }
    
    .assessment-info {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 1.5rem;
        margin-bottom: 2rem;
    }
    
    .info-card {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: var(--border-radius);
        border-left: 4px solid var(--primary-color);
    }
    
    .info-card h3 {
        color: var(--primary-color);
        margin-bottom: 1rem;
        display: flex;
        align-items: center;
        gap: 10px;
    }
`;

document.head.appendChild(additionalStyles);